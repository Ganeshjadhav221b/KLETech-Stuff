#include <stdio.h>
#include <stdlib.h>

int first();
void objectCode();
int word_count();
//void second(int l);
void objectProgram(int l);
