#include"header.h"
#include"first.c"
#include"second.c"
#include"third.c"
int main()
{
    //int length = first();

    //printf("Length of the program: %d\n",length);
    //objectCode();
    objectProgram(4175-3);
    return 0;
}

