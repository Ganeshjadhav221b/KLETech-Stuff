#include <stdio.h>
#include <stdlib.h>
#include "macro.c"

int main()
{
    getFiles();

    return 0;
}
