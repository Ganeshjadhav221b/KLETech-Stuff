#include "header.h"
#include "first.c"

int main()
{
    //first();
    second();
    return 0;
}
